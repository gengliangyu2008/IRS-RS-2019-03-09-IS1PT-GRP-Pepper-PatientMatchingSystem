package csv;

import database.DBConnection;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.Reader;
import java.sql.PreparedStatement;

public class CSVUtils {
    public static final String CSV_PATIENT_PREFERENCES =
            "C:\\Users\\gary\\Desktop\\csv_data1\\patient_perferences.csv";

    public static final String CSV_PRACTIONER_AVAILABILITY =
            "C:\\Users\\gary\\Desktop\\csv_data1\\practioner_availabilities.csv";

    public static DBConnection dbConnection = new DBConnection();

    public static void preparePatientPreferencesData() throws Exception {
        Reader in = new FileReader(CSV_PATIENT_PREFERENCES);
        Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().withHeader(
                "Sno",
                "PHQ-9 Score",
                //"Session hours needed",
                "Practitioner Role",
                "Practitioner Language",
                "Practitioner Gender",
                "Insitution Location",
                "Session Day"
        ).parse(in);

        String insertSql = "insert into phq_patient_preference values(?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pstmt = dbConnection.getConn()
                .prepareStatement(insertSql);

        for (CSVRecord record : records) {
            if(!isValid(record)){
                continue;
            }

            String sno = record.get("Sno");
            String phqScore = record.get("PHQ-9 Score");
            //String sessionHoursNeeded = record.get("Session hours needed");
            String practitionerRole = record.get("Practitioner Role");
            String practitionerLanguage = record.get("Practitioner Language");
            String practitionerGender = record.get("Practitioner Gender");
            String insitutionLocation = record.get("Insitution Location");
            String sessionDay = record.get("Session Day");

            pstmt.setInt(1, Integer.parseInt(sno));
            pstmt.setInt(2, Integer.parseInt(phqScore));
            //pstmt.setInt(3, Integer.parseInt(sessionHoursNeeded));
            pstmt.setString(3, practitionerRole);
            pstmt.setString(4, practitionerLanguage);
            pstmt.setString(5, practitionerGender);
            pstmt.setString(6, insitutionLocation);
            pstmt.setString(7, sessionDay);

            pstmt.execute();

            System.out.println("*************current inserted record sno====" + sno);
        }

        pstmt.close();
        dbConnection.closeConn();

        System.out.println("==================COMPLETED============================");
    }

    public static void preparePractionerData() throws Exception {
        Reader in = new FileReader(CSV_PRACTIONER_AVAILABILITY);
        Iterable<CSVRecord> records = CSVFormat.EXCEL.withFirstRecordAsHeader().withHeader(
                "Sno",
                "Practitioner Name",
                "Practitioner Role",
                "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun",
                "Practitioner Language",
                "Practitioner Gender",
                "Practitioner Cost",
                "Insitution Name",
                "Insitution Type",
                "Insitution Location", // this is overall location
                "Location of insitutions" // this is detail location
                //"Day_insitutions",
                //"Hour_insitutions",
                //"Contact Detail",
                //"Note"
        ).parse(in);

        String insertSql = "insert into phq_practioner_availability values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement pstmt = dbConnection.getConn()
                .prepareStatement(insertSql);

        for (CSVRecord record : records) {

            if(!isValid(record)){
                continue;
            }
            String sno = record.get("Sno");
            String practitionerName = record.get("Practitioner Name");
            String practitionerRole = record.get("Practitioner Role");
            String mon = record.get("Mon");
            String tue = record.get("Tue");
            String wed = record.get("Wed");
            String thu = record.get("Thu");
            String fri = record.get("Fri");
            String sat = record.get("Sat");
            String sun = record.get("Sun");
            String practitionerLanguage = record.get("Practitioner Language");
            String practitionerGender = record.get("Practitioner Gender");
            String practitionerCost = record.get("Practitioner Cost");
            String insitutionName = record.get("Insitution Name");
            String insitutionType = record.get("Insitution Type");
            String insitutionLocationOverall = record.get("Insitution Location");
            String insitutionLocationDetail = record.get("Location of insitutions");
            /*String insitutionDay = record.get("Day_insitutions");
            String insitutionHour = record.get("Hour_insitutions");
            String insitutionContactDetail = record.get("Contact Detail");
            String note = record.get("Note");*/

            pstmt.setInt(1, Integer.parseInt(sno));
            pstmt.setString(2, practitionerName);
            pstmt.setString(3, practitionerRole);
            pstmt.setString(4, practitionerLanguage);
            pstmt.setString(5, practitionerGender);
            pstmt.setString(6, practitionerCost);

            pstmt.setString(7, mon);
            pstmt.setString(8, tue);
            pstmt.setString(9, wed);
            pstmt.setString(10, thu);
            pstmt.setString(11, fri);
            pstmt.setString(12, sat);
            pstmt.setString(13, sun);

            pstmt.setString(14, insitutionName);
            pstmt.setString(15, insitutionType);
            pstmt.setString(16, insitutionLocationOverall);
            pstmt.setString(17, insitutionLocationDetail);
            /*pstmt.setString(18, insitutionDay);
            pstmt.setString(19, insitutionHour);
            pstmt.setString(20, insitutionContactDetail);
            pstmt.setString(21, note);*/

            pstmt.execute();

            System.out.println("*************current inserted record sno====" + sno);
        }

        pstmt.close();
        dbConnection.closeConn();

        System.out.println("==================COMPLETED============================");
    }

    private static boolean isValid(CSVRecord record) {
        return record != null && record.size() > 0 &&
                record.get("Sno") != null && !record.get("Sno").trim().isEmpty();
    }

    public static void main(String[] args) throws Exception {
        //preparePatientPreferencesData();
        preparePractionerData();
    }
}
