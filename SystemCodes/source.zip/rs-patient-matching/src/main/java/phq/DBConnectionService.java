package phq;

import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Service
public class DBConnectionService {
    public static final String URL = "jdbc:derby://localhost:1527/phq-db;create=true;user=phqadmin;password=phqadmin";
    public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver";

    public static final String EMBEDDED_URL = "jdbc:derby:phq-db;create=true;user=app;password=app";
    public static final String EMBEDDED_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";

    private Connection connection;

    public DBConnectionService() {

        try {
            Class.forName(EMBEDDED_DRIVER).newInstance();
            connection = DriverManager.getConnection(EMBEDDED_URL);
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConn() {
        return connection;
    }

    public void closeConn() {
        try {
            if(connection != null && !connection.isClosed() ) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
