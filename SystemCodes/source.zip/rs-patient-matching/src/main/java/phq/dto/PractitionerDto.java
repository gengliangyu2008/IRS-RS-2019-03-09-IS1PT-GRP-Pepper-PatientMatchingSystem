package phq.dto;

import com.phqtime.phqtimetable.PhqPractioner;
import com.phqtime.phqtimetable.UnavailableDay;
import com.phqtime.phqtimetable.WorkDay;

import java.util.ArrayList;
import java.util.List;

public class PractitionerDto {

    private int sno;
    private String name;
    private String role;
    private String language;
    private String gender;
    private String cost;
    private String monday;
    private String tuesday;
    private String wednesday;
    private String thursday;
    private String friday;
    private String saturday;
    private String sunday;
    private String institutionName;
    private String institutionType;
    private String institutionOverallLocation;
    private String institutionDetailLocation;

    public PractitionerDto(int sno, String name, String role, String language, String gender, String cost,
                           String monday, String tuesday, String wednesday, String thursday, String friday, String saturday, String sunday,
                           String institutionName, String institutionType, String institutionOverallLocation, String institutionDetailLocation) {
        this.sno = sno;
        this.name = name;
        this.role = role;
        this.language = language;
        this.gender = gender;
        this.cost = cost;
        this.monday = monday;
        this.tuesday = tuesday;
        this.wednesday = wednesday;
        this.thursday = thursday;
        this.friday = friday;
        this.saturday = saturday;
        this.sunday = sunday;
        this.institutionName = institutionName;
        this.institutionType = institutionType;
        this.institutionOverallLocation = institutionOverallLocation;
        this.institutionDetailLocation = institutionDetailLocation;
    }
/* public PractitionerDto() {
        this.sno = sno;
        this.name = name;
        this.role = role;
        this.language = language;
        this.gender = gender;
        this.cost = cost;
        this.monday = monday;
        this.tuesday = tuesday;
        this.wednesday = wednesday;
        this.thursday = thursday;
        this.friday = friday;
        this.saturday = saturday;
        this.sunday = sunday;
        this.institutionName = institutionName;
        this.institutionType = institutionType;
        this.institutionOverallLocation = institutionOverallLocation;
        this.institutionDetailLocation = institutionDetailLocation;
    }*/

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getMonday() {
        return monday;
    }

    public void setMonday(String monday) {
        this.monday = monday;
    }

    public String getTuesday() {
        return tuesday;
    }

    public void setTuesday(String tuesday) {
        this.tuesday = tuesday;
    }

    public String getWednesday() {
        return wednesday;
    }

    public void setWednesday(String wednesday) {
        this.wednesday = wednesday;
    }

    public String getThursday() {
        return thursday;
    }

    public void setThursday(String thursday) {
        this.thursday = thursday;
    }

    public String getFriday() {
        return friday;
    }

    public void setFriday(String friday) {
        this.friday = friday;
    }

    public String getSaturday() {
        return saturday;
    }

    public void setSaturday(String saturday) {
        this.saturday = saturday;
    }

    public String getSunday() {
        return sunday;
    }

    public void setSunday(String sunday) {
        this.sunday = sunday;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getInstitutionType() {
        return institutionType;
    }

    public void setInstitutionType(String institutionType) {
        this.institutionType = institutionType;
    }

    public String getInstitutionOverallLocation() {
        return institutionOverallLocation;
    }

    public void setInstitutionOverallLocation(String institutionOverallLocation) {
        this.institutionOverallLocation = institutionOverallLocation;
    }

    public String getInstitutionDetailLocation() {
        return institutionDetailLocation;
    }

    public void setInstitutionDetailLocation(String institutionDetailLocation) {
        this.institutionDetailLocation = institutionDetailLocation;
    }
}
