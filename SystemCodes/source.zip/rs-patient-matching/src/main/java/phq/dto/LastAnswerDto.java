package phq.dto;

public class LastAnswerDto {

    private String answer="0";

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
