package phq.dto;

public class QuestionDto {
}
