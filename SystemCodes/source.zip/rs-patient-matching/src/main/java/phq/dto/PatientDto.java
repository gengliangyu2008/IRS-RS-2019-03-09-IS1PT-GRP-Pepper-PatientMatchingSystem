package phq.dto;

public class PatientDto {

    private int sno;
    private int phq9Score;
    private String practitionerRole;
    private String practitionerLanguage;
    private String practitionerGender;
    private String institutionLocation;
    private String sessionDay;

    public PatientDto(int sno, int phq9Score, String practitionerRole, String practitionerLanguage, String practitionerGender, String institutionLocation, String sessionDay) {
        this.sno = sno;
        this.phq9Score = phq9Score;
        this.practitionerRole = practitionerRole;
        this.practitionerLanguage = practitionerLanguage;
        this.practitionerGender = practitionerGender;
        this.institutionLocation = institutionLocation;
        this.sessionDay = sessionDay;
    }

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public int getPhq9Score() {
        return phq9Score;
    }

    public void setPhq9Score(int phq9Score) {
        this.phq9Score = phq9Score;
    }

    public String getPractitionerRole() {
        return practitionerRole;
    }

    public void setPractitionerRole(String practitionerRole) {
        this.practitionerRole = practitionerRole;
    }

    public String getPractitionerLanguage() {
        return practitionerLanguage;
    }

    public void setPractitionerLanguage(String practitionerLanguage) {
        this.practitionerLanguage = practitionerLanguage;
    }

    public String getPractitionerGender() {
        return practitionerGender;
    }

    public void setPractitionerGender(String practitionerGender) {
        this.practitionerGender = practitionerGender;
    }

    public String getInstitutionLocation() {
        return institutionLocation;
    }

    public void setInstitutionLocation(String institutionLocation) {
        this.institutionLocation = institutionLocation;
    }

    public String getSessionDay() {
        return sessionDay;
    }

    public void setSessionDay(String sessionDay) {
        this.sessionDay = sessionDay;
    }
}
