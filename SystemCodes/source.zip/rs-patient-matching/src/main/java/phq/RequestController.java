package phq;

import phq.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Controller
public class RequestController {

    PersonDto currentPerson;

    PreferenceDto currentPreference;

    int currentScore;

    List<AnswerDto> answerDtoList = new ArrayList();

    @Autowired
    PhqCheckService phqCheckService;

    @Autowired
    PatientService patientService;

    @Autowired
    MatchingService matchingService;

    @RequestMapping("/")
    public String welcome() {
        //return "static/index.html";
        return "index";
    }

    @GetMapping("/start")
    public String start(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {

        model.addAttribute("name", name);
        PersonDto personDto = new PersonDto();
        model.addAttribute("personDto", personDto);
        return "personal_info";
    }

    /*@GetMapping("/next")
    public String nextQuestion(@ModelAttribute AnswerDto currentAnswer, @RequestParam(name="currentQ", defaultValue="1") int currentQ, Model model) {
        model.addAttribute("currentQ", currentQ);

        System.out.println("--------------------" + currentAnswer.getAnswer());
        AnswerDto answerDto = new AnswerDto();
        model.addAttribute("answerDto", answerDto);

        return "q"+(currentQ+1);
    }*/

    @PostMapping("/next")
    public String nextQuestion(@ModelAttribute AnswerDto answerDto, @RequestParam("currentSeq") String currentSeq, Model model) {

        System.out.println("currentSeq========" + currentSeq);
        System.out.println("--------------------" + answerDto.getAnswer());

        answerDtoList.add(answerDto);

        if(isPhq2CheckEligible(currentSeq)) {
            if ( phqCheckService.isPhq2Stopped(answerDtoList) ) {
                return "ph2_complete";
            }
        }
        AnswerDto nextAnswerDto = new AnswerDto();

        int nextSeq = Integer.parseInt(currentSeq) + 1;

        if( nextSeq == 10 ) {
            LastAnswerDto lastAnswerDto = new LastAnswerDto();
            model.addAttribute("lastAnswerDto", lastAnswerDto);
        }

        model.addAttribute("answerDto", nextAnswerDto);

        return "q"+ nextSeq;
    }

    private boolean isPhq2CheckEligible(String currentSeq) {
        return Integer.parseInt(currentSeq) == 2;
    }


    @PostMapping("/personal_info_submit")
    public String submitPersonalInfo(@ModelAttribute PersonDto personDto, Model model) {

        currentPerson = personDto;
        answerDtoList.clear();

        AnswerDto answerDto = new AnswerDto();
        answerDto.setQuestionNum("1");
        model.addAttribute("answerDto", answerDto);

        boolean isLowRisk = phqCheckService.isLowRisk(personDto);
        System.out.println("isLowRisk=======" + isLowRisk);

        return isLowRisk ? "low_risk_profile" : "q1";
    }

    @GetMapping("/submit")
    public String submit(@ModelAttribute AnswerDto answerDto, Model model) {

        answerDtoList.add(answerDto);

        int finalScore = phqCheckService.getFinalScore(answerDtoList);
        currentScore = finalScore;

        // **** IMPORTANT TO DO : hard code isAlert to true temporarily for testing.
        // Finally, still need to call phq service to get the result.
        boolean isAlert = phqCheckService.isAlertFromPhq9(answerDtoList);

        //boolean isAlert = true;

        model.addAttribute("finalScore", finalScore);
        model.addAttribute("isAlert", isAlert);

        return isAlert ? "complete_blue" : "complete";
    }

    @PostMapping("/submit")
    public String submit11(Model model) {
        return "complete";
    }

/*
    @GetMapping("/genericAnswer")
    public String getGenericAnswer() {
        return "genericAnswer";
    }

    @GetMapping("/q10Answer")
    public String getQ10Answer() {
        return "q10Answer";
    }

    @GetMapping("/finalAnswer")
    public String getFinalAnswer() {
        return "finalAnswer";
    }*/

    @GetMapping("/goToPreference")
    public String startAppointment(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {

        model.addAttribute("name", name);
        PreferenceDto preferenceDto = new PreferenceDto();
        model.addAttribute("preferenceDto", preferenceDto);
        return "personal_preference";
    }

    @PostMapping("/preference_info_submit")
    public String submitPatientPreferenceInfo(@ModelAttribute PreferenceDto preferenceDto, Model model) {

        currentPreference = preferenceDto;

        int id = -1;
        try {
            id = patientService.insertNewPatient(currentPreference, currentScore);
        } catch (Exception e) {
            e.printStackTrace();
        }

        model.addAttribute("savedPatientId", id);
        return "preferenceInfoSaved";
    }

    @GetMapping("/backToMain")
    public String goToMain() throws Exception{
        return "index";
    }

    @GetMapping("/show_patients")
    public String showPatients(Model model) throws Exception{
        List<PatientDto> list = patientService.getAllPatients();
        model.addAttribute("patientList", list);
        return "displayPatient";
    }

    @GetMapping("/show_practitioners")
    public String showPractitioners(Model model) throws Exception{
        List<PractitionerDto> list = patientService.getAllPractioners();
        for(PractitionerDto dto : list) {
            dto.setMonday(dto.getMonday().replaceAll(" ", "<br/>"));
            dto.setTuesday(dto.getTuesday().replaceAll(" ", "<br/>"));
            dto.setWednesday(dto.getWednesday().replaceAll(" ", "<br/>"));
            dto.setThursday(dto.getThursday().replaceAll(" ", "<br/>"));
            dto.setFriday(dto.getFriday().replaceAll(" ", "<br/>"));
            dto.setSaturday(dto.getSaturday().replaceAll(" ", "<br/>"));
            dto.setSunday(dto.getSunday().replaceAll(" ", "<br/>"));
        }
        model.addAttribute("practitionerList", list);
        return "displayPractitioner";
    }

    @GetMapping("/go_to_matching")
    public String goToMatching(Model model) throws Exception{
        int numOfPatients = patientService.getNumOfPatients();
        int numOfPractitioners = patientService.getNumOfPractitioners();

        model.addAttribute("numOfPatients", numOfPatients);
        model.addAttribute("numOfPractitioners", numOfPractitioners);

        return "matchingParameters";
    }

    @GetMapping("/start_loadingNew")
    public String startLoadingNew(Model model) throws Exception{

        return "matchLoadingNew";
    }

    @GetMapping("/start_loading")
    public String startLoading(Model model) throws Exception{

        /*MatchResultSummaryDto matchResult = matchingService.matching();
        model.addAttribute("matchResult", matchResult);
        return "matchResult";*/

        startMatchingInNewThread();

        return "matchLoading";
    }

    @GetMapping("/showResults")
    public String matchingComplete(Model model) throws Exception{

        MatchResultSummaryDto matchResult = matchingService.matching();
        //MatchResultSummaryDto matchResult = matchingService.getLatestResult();
        model.addAttribute("matchResult", matchResult);
        return "matchResult";
    }

    public void startMatchingInNewThread() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            try {
                matchingService.matching();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
