package com.phqtime.phqtimetable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WorkPeriod")
public class WorkPeriod implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final List<WorkPeriod> PERIOD_LIST = constructPeriodList(WorkDay.getAllWorkDayList(), WorkTimeslot.getAllTimeslotList());
	
	private long id;
	private WorkDay day;
	private WorkTimeslot timeslot;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public WorkDay getDay() {
		return day;
	}

	public void setDay(WorkDay day) {
		this.day = day;
	}

	public WorkTimeslot getTimeslot() {
		return timeslot;
	}

	public void setTimeslot(WorkTimeslot timeslot) {
		this.timeslot = timeslot;
	}

	@Override
	public String toString() {
		return day.toString() + "-" + timeslot.toString();
	}

	public WorkPeriod(long id, WorkDay day, WorkTimeslot timeslot) {
		this.id = id;
		this.day = day;
		this.timeslot = timeslot;
	}
	
	public String getDesc() {
		StringBuffer buf = new StringBuffer();
		buf.append("id: ").append(id).append(", ");
		buf.append("day: ").append(day.getDesc()).append(", ");
		buf.append("time: ").append(timeslot.getDesc());
		
		return buf.toString();
	}
	
	public static List<WorkPeriod> getAllPeriodList() {
		return PERIOD_LIST;
	}
	
	public static Map<String, WorkPeriod> constructPeriodMap() {
		Map<String, WorkPeriod> periodMap = new HashMap<String, WorkPeriod>();
		for (WorkPeriod period : PERIOD_LIST) {
			String periodKey = period.toString();
			periodMap.put(periodKey, period);
		}
		
		return periodMap;
	}
	
	private static List<WorkPeriod> constructPeriodList(List<WorkDay> dayList, List<WorkTimeslot> slotList) {
		List<WorkPeriod> periodList = new ArrayList<WorkPeriod>();
		
		long periodId = 0;
    	for (int i = 0; i < dayList.size(); ++i) {
    		WorkDay day = dayList.get(i);
    		List<WorkPeriod> dayPeriodList = new ArrayList<WorkPeriod>(slotList.size());
    		day.setPeriodList(dayPeriodList);
    		
    		for (int j = 0; j < slotList.size(); ++j) {
    			WorkTimeslot timeslot = slotList.get(j);
    			WorkPeriod currentPeriod = new WorkPeriod(periodId, day, timeslot);
    			dayPeriodList.add(currentPeriod);
    			periodList.add(currentPeriod);
    			periodId++;
    		}
    	}
    	
    	return periodList;
	}
}