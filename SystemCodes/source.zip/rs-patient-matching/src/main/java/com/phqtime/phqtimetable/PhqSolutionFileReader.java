/**
 * 
 */
package com.phqtime.phqtimetable;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import org.kie.soup.commons.xstream.XStreamUtils;
import org.optaplanner.persistence.common.api.domain.solution.SolutionFileIO;

import com.thoughtworks.xstream.XStream;

/**
 * @author caoliang
 *
 */
public class PhqSolutionFileReader<Solution_> implements SolutionFileIO<Solution_> {

	@Override
	public String getInputFileExtension() {
		return "xml";
	}

	@SuppressWarnings("unchecked")
	@Override
	public Solution_ read(File inputSolutionFile) {
		try {
            XStream readStream = XStreamUtils.createTrustingXStream();
            return (Solution_)readStream.fromXML(new FileReader(inputSolutionFile));
		} catch (Exception exp) {
			throw new IllegalArgumentException("Failed reading inputSolutionFile (" + inputSolutionFile + ").", exp);
		}
	}

	@Override
	public void write(Solution_ solution, File outputSolutionFile) {
        try {
    		XStream writeStream = XStreamUtils.createTrustingXStream();
            writeStream.toXML(solution, new FileWriter(outputSolutionFile));
		} catch (Exception exp) {
			throw new IllegalArgumentException("Failed writing outputSolutionFile (" + outputSolutionFile + ").", exp);
		}
		
	}
	

}
